"""AlphaLab application entrypoints."""
