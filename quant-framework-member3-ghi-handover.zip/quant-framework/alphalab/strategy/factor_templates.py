"""Canonical Python templates for the built-in factor catalog."""

from __future__ import annotations

import ast
import re
import textwrap
from dataclasses import asdict, dataclass
from typing import Any, Mapping

import libcst as cst

from alphalab.strategy.source import SourceInspection, StrategySourceError, inspect_strategy_source


@dataclass(frozen=True)
class FactorTemplate:
    id: str
    label: str
    category: str
    description: str
    inputs: tuple[str, ...]
    requirements: Mapping[str, tuple[str, ...]]
    recommended_direction: str
    source: str

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["inputs"] = list(self.inputs)
        payload["requirements"] = {
            dataset: list(fields) for dataset, fields in self.requirements.items()
        }
        return payload


def _technical(
    factor_id: str,
    label: str,
    description: str,
    inputs: tuple[str, ...],
    source: str,
    *,
    direction: str = "higher",
) -> FactorTemplate:
    return FactorTemplate(
        id=factor_id,
        label=label,
        category="technical",
        description=description,
        inputs=inputs,
        requirements={"bars": inputs},
        recommended_direction=direction,
        source=source.strip() + "\n",
    )


def _fundamental(
    factor_id: str,
    label: str,
    description: str,
    *,
    direction: str = "higher",
) -> FactorTemplate:
    return FactorTemplate(
        id=factor_id,
        label=label,
        category="fundamental",
        description=description,
        inputs=(factor_id,),
        requirements={"fundamentals": (factor_id,)},
        recommended_direction=direction,
        source=(
            f'@factor(id="{factor_id}", label="{label}")\n'
            f"def {factor_id}(context):\n"
            f'    """读取截至评估日可见的“{label}”横截面。\n\n'
            f"    返回值以证券代码为索引；缺失披露保留为 NaN，由策略决定是否剔除。\n"
            f'    """\n'
            f"    # fundamental() 使用点时可见数据，不会用回测结束日数值回填历史。\n"
            f'    return context.fundamental("{factor_id}")\n'
        ),
    )


FACTOR_TEMPLATES = (
    _technical(
        "lower_shadow_recovery",
        "下影线收回",
        "下影线占振幅至少 40%，收盘位于振幅上部 35%；形态条件，不代表资金流入。",
        ("open", "high", "low", "close"),
        """
@factor(id="lower_shadow_recovery", label="下影线收回")
def lower_shadow_recovery(context, *, shadow_min: float = 0.4, close_min: float = 0.65):
    '''返回 0/1 形态横截面；缺失或零振幅保留 NaN，不宣称预测胜率。'''
    import pandas as pd
    # context.history 仅包含当前评估时点可见的日线。
    close = context.history("close", window=1)
    if close.empty:
        return close.mean(axis=0) * float("nan")
    bars = pd.concat({name: context.history(name, window=1).reindex_like(close).iloc[-1]
                      for name in ("open", "high", "low", "close")}, axis=1)
    span = bars.high - bars.low
    valid = bars.notna().all(axis=1) & span.gt(0) & bars.min(axis=1).gt(0)
    valid &= bars.high.ge(bars[["open", "close"]].max(axis=1)) & bars.low.le(bars[["open", "close"]].min(axis=1))
    shadow = (bars[["open", "close"]].min(axis=1) - bars.low) / span
    location = (bars.close - bars.low) / span
    return ((shadow >= shadow_min) & (location >= close_min)).astype(float).where(valid)
""",
    ),
    _technical(
        "three_white_soldiers",
        "三连阳实体形态",
        "三日阳线收盘递升、开盘落在前日实体内且上影较短；三白兵的显式代理定义。",
        ("open", "high", "low", "close"),
        """
@factor(id="three_white_soldiers", label="三连阳实体形态")
def three_white_soldiers(context, *, body_min: float = 0.5, upper_max: float = 0.25):
    '''三白兵代理条件返回 0/1；三日历史缺失时返回 NaN。'''
    close = context.history("close", window=3)
    if len(close) < 3:
        return close.mean(axis=0) * float("nan")
    opening = context.history("open", window=3).reindex_like(close)
    high = context.history("high", window=3).reindex_like(close)
    low = context.history("low", window=3).reindex_like(close)
    span = high - low
    # 不用 fillna 将未知行情变成不满足形态；缺失证券保持未知。
    valid = close.notna().all() & opening.notna().all() & high.notna().all() & low.notna().all()
    valid &= (span > 0).all() & (low > 0).all()
    valid &= (high >= close).all() & (high >= opening).all() & (low <= close).all() & (low <= opening).all()
    rising = (close > opening).all() & (close.diff().iloc[1:] > 0).all()
    inside = (opening.iloc[1:] >= opening.shift().iloc[1:]).all() & (opening.iloc[1:] <= close.shift().iloc[1:]).all()
    shape = (((close - opening) / span) >= body_min).all() & (((high - close) / span) <= upper_max).all()
    return (rising & inside & shape).astype(float).where(valid)
""",
    ),
    _technical(
        "volume_confirmed_breakout",
        "放量突破前高",
        "收盘突破此前 20 日最高价，成交量达到此前 20 日均量的 1.5 倍。",
        ("close", "high", "volume"),
        """
@factor(id="volume_confirmed_breakout", label="放量突破前高")
def volume_confirmed_breakout(context, *, window: int = 20, volume_multiple: float = 1.5):
    '''返回 0/1 突破条件；窗口不足、缺失或历史零成交量保持 NaN。'''
    close = context.history("close", window=window + 1)
    if len(close) < window + 1:
        return close.mean(axis=0) * float("nan")
    high = context.history("high", window=window + 1).reindex_like(close)
    volume = context.history("volume", window=window + 1).reindex_like(close)
    # 阻力和基准成交量均剔除当日，防止当日突破抬高自身阈值。
    prior_high = high.iloc[:-1].max()
    prior_volume = volume.iloc[:-1].mean()
    valid = close.notna().all() & high.notna().all() & volume.notna().all()
    valid &= (close > 0).all() & (high >= close).all() & (volume >= 0).all() & (prior_volume > 0)
    return ((close.iloc[-1] > prior_high) & (volume.iloc[-1] >= volume_multiple * prior_volume)).astype(float).where(valid)
""",
    ),
    _technical(
        "momentum_20d",
        "20 日动量",
        "最近 20 个交易日的价格涨跌幅。",
        ("close",),
        """
@factor(id="momentum_20d", label="20 日动量")
def momentum_20d(context, *, window: int = 20):
    '''计算最近 window 个交易日的累计收益率，返回证券横截面。'''
    # 多读取一个收盘价，才能形成完整的 window 段收益。
    close = context.history("close", window=window + 1)
    if len(close.index) < window + 1:
        # 历史不足时保留 NaN，避免用不完整窗口制造动量信号。
        return close.mean(axis=0) * float("nan")
    return close.iloc[-1] / close.iloc[0] - 1.0
""",
    ),
    _technical(
        "momentum_60d",
        "60 日动量",
        "最近 60 个交易日的中期价格动量。",
        ("close",),
        """
@factor(id="momentum_60d", label="60 日动量")
def momentum_60d(context, *, window: int = 60):
    '''计算中期累计收益率；window 可在因子编辑器中调整。'''
    # 历史矩阵以日期为索引、证券代码为列，且不会越过当前评估日。
    close = context.history("close", window=window + 1)
    if len(close.index) < window + 1:
        # 用同列结构的 NaN Series 表达“当前不可计算”。
        return close.mean(axis=0) * float("nan")
    return close.iloc[-1] / close.iloc[0] - 1.0
""",
    ),
    _technical(
        "reversal_5d",
        "5 日反转",
        "最近 5 个交易日涨跌幅，通常以低值优先使用。",
        ("close",),
        """
@factor(id="reversal_5d", label="5 日反转")
def reversal_5d(context, *, window: int = 5):
    '''返回短期累计收益率；作为反转因子时通常按低值优先排序。'''
    # 多取一个价格观察值，以获得完整的 window 日涨跌幅。
    close = context.history("close", window=window + 1)
    if len(close.index) < window + 1:
        # 新上市标的历史不足时不进入本期有效排序。
        return close.mean(axis=0) * float("nan")
    return close.iloc[-1] / close.iloc[0] - 1.0
""",
        direction="lower",
    ),
    _technical(
        "volatility_20d",
        "20 日波动率",
        "最近 20 日收益率的年化波动率，通常以低值优先使用。",
        ("close",),
        """
@factor(id="volatility_20d", label="20 日波动率")
def volatility_20d(context, *, window: int = 20, annualization_days: int = 252):
    '''用日收益标准差估计年化波动率，通常按低值优先使用。'''
    # window+1 个价格产生 window 个简单收益率。
    close = context.history("close", window=window + 1)
    returns = close.pct_change().tail(window)
    # ddof=0 让短窗口定义稳定；年化周期由显式参数控制。
    return returns.std(ddof=0) * (annualization_days ** 0.5)
""",
        direction="lower",
    ),
    _technical(
        "turnover_20d",
        "20 日平均成交量",
        "最近 20 日的平均成交量，用于刻画流动性。",
        ("volume",),
        """
@factor(id="turnover_20d", label="20 日平均成交量")
def turnover_20d(context, *, window: int = 20):
    '''返回最近 window 日平均成交量，作为相对流动性代理。'''
    # 成交量适合在同类资产内比较；跨资产类型时应先统一单位口径。
    volume = context.history("volume", window=window)
    return volume.mean()
""",
    ),
    _technical(
        "liquidity_20d",
        "20 日平均成交额",
        "最近 20 日平均成交额，用于刻画可交易容量与流动性。",
        ("amount",),
        """
@factor(id="liquidity_20d", label="20 日平均成交额")
def liquidity_20d(context, *, window: int = 20):
    '''返回最近 window 日平均成交额，用于衡量流动性和可交易容量。'''
    # amount 比单纯 volume 更适合比较价格水平不同的证券。
    amount = context.history("amount", window=window)
    return amount.mean()
""",
    ),
    _technical(
        "range_volatility_20d",
        "20 日日内振幅",
        "最近 20 日高低价差相对收盘价的均值，通常以低值优先使用。",
        ("high", "low", "close"),
        """
@factor(id="range_volatility_20d", label="20 日日内振幅")
def range_volatility_20d(context, *, window: int = 20):
    '''计算高低价差相对收盘价的均值，通常按低值优先使用。'''
    high = context.history("high", window=window)
    low = context.history("low", window=window)
    # 零收盘价先转为 NaN，避免产生无穷值污染横截面。
    close = context.history("close", window=window).replace(0.0, float("nan"))
    return ((high - low) / close).mean()
""",
        direction="lower",
    ),
    _technical(
        "volume_ratio",
        "成交量比率",
        "近 5 日平均成交量与近 20 日平均成交量之比。",
        ("volume",),
        """
@factor(id="volume_ratio", label="成交量比率")
def volume_ratio(context, *, short_window: int = 5, long_window: int = 20):
    '''比较短期与长期平均成交量，识别近期放量或缩量。'''
    # 一次读取最长窗口，保证短、长统计使用相同的评估时点和标的列。
    volume = context.history("volume", window=long_window)
    # 长期均量为零时不应给出可排序的比率。
    baseline = volume.mean().replace(0.0, float("nan"))
    return volume.tail(short_window).mean() / baseline
""",
    ),
    _technical(
        "rsi_14",
        "14 日 RSI",
        "14 日相对强弱指标。",
        ("close",),
        """
@factor(id="rsi_14", label="14 日 RSI")
def rsi_14(context, *, window: int = 14):
    '''按 Wilder RSI 的涨跌均值形式返回 0 到 100 的强弱指标。'''
    close = context.history("close", window=window + 1)
    delta = close.diff().tail(window)
    gains = delta.clip(lower=0.0).mean()
    losses = (-delta.clip(upper=0.0)).mean()
    # 无下跌样本时先使用安全分母，最后明确映射为 RSI=100。
    safe_losses = losses.where(losses > 0.0, 1.0)
    score = 100.0 - 100.0 / (1.0 + gains / safe_losses)
    return score.where(losses > 0.0, 100.0)
""",
    ),
    _technical(
        "ma_deviation",
        "均线偏离",
        "收盘价相对 20 日均线的偏离程度。",
        ("close",),
        """
@factor(id="ma_deviation", label="均线偏离")
def ma_deviation(context, *, window: int = 20):
    '''返回最新收盘价相对 window 日简单移动平均线的偏离比例。'''
    close = context.history("close", window=window)
    if len(close.index) < window:
        # 不用短窗口代替完整均线，避免新上市标的获得不可比数值。
        return close.mean(axis=0) * float("nan")
    # 零均线没有经济意义，显式转换为缺失值。
    moving_average = close.mean().replace(0.0, float("nan"))
    return close.iloc[-1] / moving_average - 1.0
""",
    ),
    _fundamental("ep", "盈利收益率", "盈利相对估值水平。"),
    _fundamental("bp", "账面市值比", "账面价值相对市值水平。"),
    _fundamental("roe", "净资产收益率", "TTM 归母利润 / 当前与去年同期平均正净资产；缺季不拼接。"),
    _fundamental("roa", "总资产收益率", "TTM 归母利润 / 当前与去年同期平均正总资产；质量研究代理口径。"),
    FactorTemplate(
        id="quality_profitability",
        label="盈利与低杠杆质量代理",
        category="fundamental",
        description="ROE、ROA、负债率反向排名的等权组合；不是任何已识别指数的精确公式。",
        inputs=("roe", "roa", "leverage"),
        requirements={"fundamentals": ("roe", "roa", "leverage")},
        recommended_direction="higher",
        source='''@factor(id="quality_profitability", label="盈利与低杠杆质量代理")
def quality_profitability(context):
    """在传入股票池内返回质量排名均值；任一输入缺失则保持 NaN。"""
    import pandas as pd
    # 股票池应先按历史成分与流动性筛选；不同股票池的百分位不可混用。
    values = pd.concat({name: context.fundamental(name) for name in ("roe", "roa", "leverage")}, axis=1)
    values = values.replace([float("inf"), float("-inf")], float("nan"))
    values["leverage"] = -values["leverage"]
    complete = values.notna().all(axis=1)
    return values.where(complete).rank(pct=True).mean(axis=1).where(complete)
''',
    ),
    _fundamental("profit_growth", "利润增长率", "利润同比或可比口径增长率。"),
    _fundamental("revenue_growth", "收入增长率", "营业收入增长率。"),
    _fundamental("gross_margin", "毛利率", "主营业务毛利水平。"),
    _fundamental(
        "leverage",
        "财务杠杆",
        "资产负债或权益杠杆水平，通常以低值优先使用。",
        direction="lower",
    ),
    _technical(
        "custom_factor",
        "自定义因子骨架",
        "由项目创建器复制后，仅替换函数体和字面量参数的通用因子骨架。",
        ("close",),
        """
@factor(id="custom_factor", label="自定义因子骨架")
def custom_factor(context, *, window: int = 20):
    '''通用因子骨架；创建项目时应为副本指定唯一 id 并替换函数体。'''
    # 默认实现返回最新收盘价；实际研究逻辑由副本自己的函数体明确给出。
    close = context.history("close", window=window)
    return close.iloc[-1]
""",
    ),
)

_BY_ID = {item.id: item for item in FACTOR_TEMPLATES}


def list_factor_templates() -> tuple[FactorTemplate, ...]:
    return FACTOR_TEMPLATES


def get_factor_template(template_id: str) -> FactorTemplate:
    try:
        return _BY_ID[str(template_id).strip()]
    except KeyError:
        raise StrategySourceError(
            f"unknown factor template {template_id!r}", phase="edit"
        ) from None


_PYTHON_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def instantiate_factor_template(
    template_id: str,
    *,
    factor_id: str | None = None,
    label: str | None = None,
    parameter_values: Mapping[str, Any] | None = None,
    body: str | None = None,
) -> str:
    """Create one factor unit by editing a canonical factor template copy."""

    template = get_factor_template(template_id)
    selected_id = str(factor_id or template.id).strip()
    if not _PYTHON_IDENTIFIER.fullmatch(selected_id):
        raise StrategySourceError(
            "factor_id must be a valid Python identifier", phase="edit"
        )
    if template.id == "custom_factor" and factor_id is None:
        raise StrategySourceError(
            "custom_factor requires an explicit factor_id", phase="edit"
        )
    selected_label = str(label or (selected_id if factor_id else template.label)).strip()
    if not selected_label:
        raise StrategySourceError("factor label must not be empty", phase="edit")

    module = cst.parse_module(template.source)
    functions = [item for item in module.body if isinstance(item, cst.FunctionDef)]
    if len(functions) != 1:
        raise StrategySourceError(
            f"factor template {template.id!r} must contain exactly one function",
            phase="edit",
        )
    function = _copy_factor_function(
        functions[0], factor_id=selected_id, label=selected_label
    ).with_changes(leading_lines=functions[0].leading_lines)

    values = dict(parameter_values or {})
    editable = {
        parameter.name.value: parameter
        for parameter in function.params.kwonly_params
        if parameter.default is not None
    }
    unknown = sorted(set(values) - set(editable))
    if unknown:
        raise StrategySourceError(
            f"factor parameters are not template-editable: {unknown}", phase="edit"
        )
    if values:
        updated_parameters = []
        for parameter in function.params.kwonly_params:
            if parameter.name.value not in values:
                updated_parameters.append(parameter)
                continue
            literal = repr(values[parameter.name.value])
            try:
                ast.literal_eval(literal)
                expression = cst.parse_expression(literal)
            except (SyntaxError, ValueError, TypeError) as exc:
                raise StrategySourceError(
                    f"factor parameter {parameter.name.value!r} must be a literal",
                    phase="edit",
                ) from exc
            updated_parameters.append(parameter.with_changes(default=expression))
        function = function.with_changes(
            params=function.params.with_changes(kwonly_params=tuple(updated_parameters))
        )

    if body is not None:
        normalized_body = textwrap.dedent(str(body)).strip()
        if not normalized_body:
            raise StrategySourceError("factor template body must not be empty", phase="edit")
        try:
            wrapper = cst.parse_module(
                "def _factor_template_body():\n"
                + textwrap.indent(normalized_body, "    ")
                + "\n"
            )
        except cst.ParserSyntaxError as exc:
            raise StrategySourceError(
                f"factor template body has invalid Python syntax: {exc}", phase="parse"
            ) from exc
        replacement = wrapper.body[0]
        assert isinstance(replacement, cst.FunctionDef)
        function = function.with_changes(body=replacement.body)

    updated = module.with_changes(
        body=tuple(function if item is functions[0] else item for item in module.body)
    ).code
    parsed = ast.parse(updated)
    factor_functions = [
        item
        for item in parsed.body
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
    ]
    if len(factor_functions) != 1:
        raise StrategySourceError(
            "instantiated factor template must contain exactly one function", phase="edit"
        )
    return updated


class _RequirementsTransformer(cst.CSTTransformer):
    def __init__(self, value: cst.BaseExpression) -> None:
        self.value = value
        self.changed = False

    def leave_Assign(self, original_node: cst.Assign, updated_node: cst.Assign) -> cst.Assign:
        if any(
            isinstance(target.target, cst.Name) and target.target.value == "DATA_REQUIREMENTS"
            for target in original_node.targets
        ):
            self.changed = True
            return updated_node.with_changes(value=self.value)
        return updated_node

    def leave_AnnAssign(
        self, original_node: cst.AnnAssign, updated_node: cst.AnnAssign
    ) -> cst.AnnAssign:
        if (
            isinstance(original_node.target, cst.Name)
            and original_node.target.value == "DATA_REQUIREMENTS"
        ):
            self.changed = True
            return updated_node.with_changes(value=self.value)
        return updated_node


def _has_factor_import(source: str) -> bool:
    tree = ast.parse(source)
    return any(
        isinstance(node, ast.ImportFrom)
        and node.module == "alphalab.sdk.v1"
        and any(alias.name == "factor" and alias.asname in {None, "factor"} for alias in node.names)
        for node in tree.body
    )


def _assignment_name(statement: cst.BaseStatement) -> str | None:
    if not isinstance(statement, cst.SimpleStatementLine) or len(statement.body) != 1:
        return None
    item = statement.body[0]
    if isinstance(item, cst.Assign) and len(item.targets) == 1:
        target = item.targets[0].target
        return target.value if isinstance(target, cst.Name) else None
    if isinstance(item, cst.AnnAssign) and isinstance(item.target, cst.Name):
        return item.target.value
    return None


def _decorator_name(decorator: cst.Decorator) -> str | None:
    value = decorator.decorator
    target = value.func if isinstance(value, cst.Call) else value
    if isinstance(target, cst.Name):
        return target.value
    if isinstance(target, cst.Attribute):
        return target.attr.value
    return None


def _factor_copy_identity(
    template: FactorTemplate,
    *,
    occupied: set[str],
) -> tuple[str, str]:
    copy_number = 1
    factor_id = template.id
    while factor_id in occupied:
        copy_number += 1
        factor_id = f"{template.id}_{copy_number}"
    label = template.label if copy_number == 1 else f"{template.label}（副本 {copy_number}）"
    return factor_id, label


def _copy_factor_function(
    function: cst.FunctionDef,
    *,
    factor_id: str,
    label: str,
) -> cst.FunctionDef:
    decorators: list[cst.Decorator] = []
    for decorator in function.decorators:
        value = decorator.decorator
        if _decorator_name(decorator) != "factor" or not isinstance(value, cst.Call):
            decorators.append(decorator)
            continue
        arguments: list[cst.Arg] = []
        found_id = False
        found_label = False
        for argument in value.args:
            keyword = argument.keyword.value if isinstance(argument.keyword, cst.Name) else None
            if keyword == "id":
                argument = argument.with_changes(value=cst.SimpleString(repr(factor_id)))
                found_id = True
            elif keyword == "label":
                argument = argument.with_changes(value=cst.SimpleString(repr(label)))
                found_label = True
            arguments.append(argument)
        if not found_id:
            arguments.append(
                cst.Arg(value=cst.SimpleString(repr(factor_id)), keyword=cst.Name("id"))
            )
        if not found_label:
            arguments.append(
                cst.Arg(value=cst.SimpleString(repr(label)), keyword=cst.Name("label"))
            )
        decorators.append(
            decorator.with_changes(decorator=value.with_changes(args=tuple(arguments)))
        )
    return function.with_changes(
        name=cst.Name(factor_id),
        decorators=tuple(decorators),
        leading_lines=(cst.EmptyLine(), cst.EmptyLine()),
    )


def install_factor_template(source: str, *, template_id: str) -> tuple[str, SourceInspection]:
    inspection = inspect_strategy_source(source)
    template = get_factor_template(template_id)
    registered_ids = {item.id for item in inspection.entrypoints}
    tree = ast.parse(source)
    top_level_functions = {
        node.name for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    factor_id, label = _factor_copy_identity(
        template,
        occupied=registered_ids | top_level_functions,
    )

    requirements = {
        dataset: list(fields) for dataset, fields in inspection.data_requirements.items()
    }
    for dataset, fields in template.requirements.items():
        current = requirements.setdefault(dataset, [])
        current.extend(field for field in fields if field not in current)

    module = cst.parse_module(source)
    requirement_value = cst.parse_expression(repr(requirements))
    requirement_transformer = _RequirementsTransformer(requirement_value)
    module = module.visit(requirement_transformer)
    body = list(module.body)

    if not requirement_transformer.changed:
        assignment = cst.parse_statement(f"DATA_REQUIREMENTS = {requirements!r}\n")
        sdk_index = next(
            (
                index
                for index, statement in enumerate(body)
                if _assignment_name(statement) == "SDK_VERSION"
            ),
            -1,
        )
        body.insert(sdk_index + 1, assignment)

    if not _has_factor_import(source):
        factor_import = cst.parse_statement("from alphalab.sdk.v1 import factor\n")
        import_indexes = [
            index
            for index, statement in enumerate(body)
            if isinstance(statement, cst.SimpleStatementLine)
            and statement.body
            and isinstance(statement.body[0], (cst.Import, cst.ImportFrom))
        ]
        body.insert((import_indexes[-1] + 1) if import_indexes else 0, factor_import)

    template_module = cst.parse_module(template.source)
    function = next(
        (item for item in template_module.body if isinstance(item, cst.FunctionDef)), None
    )
    if function is None:
        raise StrategySourceError("factor template is invalid", phase="edit")
    function = _copy_factor_function(function, factor_id=factor_id, label=label)
    signal_index = next(
        (
            index
            for index, statement in enumerate(body)
            if isinstance(statement, cst.FunctionDef)
            and any(_decorator_name(item) == "signal" for item in statement.decorators)
        ),
        len(body),
    )
    body.insert(signal_index, function)
    updated = module.with_changes(body=tuple(body)).code
    return updated, inspect_strategy_source(updated)


__all__ = [
    "FACTOR_TEMPLATES",
    "FactorTemplate",
    "get_factor_template",
    "install_factor_template",
    "list_factor_templates",
]
