"""Cross-sectional factor calculation shared by signals and research diagnostics."""
from __future__ import annotations

import numpy as np
import pandas as pd

from alphalab.factors.expression import (
    FUNDAMENTAL_DATA_FIELDS,
    MARKET_DATA_FIELDS,
    evaluate_factor_expression,
    factor_dependencies,
)
from alphalab.factors.fundamental import FundamentalFactors
from alphalab.factors.technical import TechnicalFactors
from alphalab.strategy.config import FactorSpec


def factor_input_names(factor: FactorSpec) -> tuple[str, ...]:
    if factor.source == "expression":
        return factor_dependencies(factor.expression or "")
    return (factor.name,)


def required_fundamental_fields(
    factors: list[FactorSpec] | tuple[FactorSpec, ...],
    *,
    market_fields: set[str] | None = None,
) -> list[str]:
    technical = set(TechnicalFactors().available_factors)
    known_market = set(MARKET_DATA_FIELDS) | set(market_fields or ())
    fields: set[str] = set()
    for factor in factors:
        fields.update(
            name
            for name in factor_input_names(factor)
            if name not in technical and name not in known_market
        )
        fields.update(factor.neutralize)
    return sorted(fields)


def compute_cross_sectional_factor(
    factor: FactorSpec,
    data_by_symbol: dict[str, pd.DataFrame],
    fundamentals: pd.DataFrame,
) -> pd.Series:
    """Compute, winsorize, and optionally neutralize one factor snapshot."""

    technical = TechnicalFactors()
    fundamental = FundamentalFactors()
    inputs: dict[str, pd.Series] = {}
    for name in factor_input_names(factor):
        if name in technical.available_factors:
            inputs[name] = technical.compute(name, data_by_symbol)
        elif name in FundamentalFactors.available_factors:
            inputs[name] = fundamental.compute(name, fundamentals)
        elif name in MARKET_DATA_FIELDS or any(
            name in frame.columns for frame in data_by_symbol.values()
        ):
            inputs[name] = _latest_market_field(name, data_by_symbol)
        elif name in FUNDAMENTAL_DATA_FIELDS or name in fundamentals.columns:
            inputs[name] = _latest_fundamental_field(name, fundamentals)
        else:
            raise KeyError(f"Unknown base factor: {name}")
    if factor.source == "expression":
        values = evaluate_factor_expression(factor.expression or "", inputs)
    else:
        values = inputs[factor.name]
    values = pd.to_numeric(values, errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()
    if values.empty:
        return pd.Series(dtype=float, name=factor.name)
    if factor.winsorize > 0 and len(values) >= 4:
        lower = float(values.quantile(factor.winsorize))
        upper = float(values.quantile(1.0 - factor.winsorize))
        values = values.clip(lower=lower, upper=upper)
    if factor.neutralize:
        values = _neutralize(values, fundamentals, factor.neutralize)
    return values.rename(factor.name).dropna()


def _latest_market_field(
    name: str,
    data_by_symbol: dict[str, pd.DataFrame],
) -> pd.Series:
    values: dict[str, float] = {}
    for symbol, frame in data_by_symbol.items():
        if frame.empty or name not in frame:
            continue
        value = pd.to_numeric(frame.sort_values("date")[name], errors="coerce").dropna()
        if not value.empty and np.isfinite(value.iloc[-1]):
            values[str(symbol).upper()] = float(value.iloc[-1])
    return pd.Series(values, name=name, dtype=float)


def _latest_fundamental_field(name: str, fundamentals: pd.DataFrame) -> pd.Series:
    if fundamentals.empty or name not in fundamentals:
        return pd.Series(dtype=float, name=name)
    latest = fundamentals.copy()
    sort_columns = [column for column in ("available_date", "quarter") if column in latest]
    if sort_columns:
        latest = latest.sort_values(sort_columns)
    latest = latest.groupby("symbol").tail(1).set_index("symbol")
    return pd.to_numeric(latest[name], errors="coerce").rename(name)


def _neutralize(
    values: pd.Series,
    fundamentals: pd.DataFrame,
    neutralizers: tuple[str, ...],
) -> pd.Series:
    if fundamentals.empty:
        raise ValueError("factor neutralization requires point-in-time fundamentals")
    latest = fundamentals.copy()
    sort_columns = [column for column in ("available_date", "quarter") if column in latest]
    if sort_columns:
        latest = latest.sort_values(sort_columns)
    latest = latest.groupby("symbol").tail(1).set_index("symbol")
    design = pd.DataFrame(index=values.index)
    for name in neutralizers:
        if name != "market_cap" or name not in latest:
            raise ValueError(f"factor neutralization requires {name}")
        raw = pd.to_numeric(latest[name], errors="coerce").reindex(values.index)
        design[name] = np.log(raw.where(raw > 0))
    aligned = pd.concat([values.rename("factor"), design], axis=1).dropna()
    if len(aligned) <= len(neutralizers) + 1:
        raise ValueError("factor neutralization has insufficient cross-sectional coverage")
    matrix = np.column_stack(
        [np.ones(len(aligned)), *[aligned[name].to_numpy(dtype=float) for name in neutralizers]]
    )
    coefficients, *_ = np.linalg.lstsq(
        matrix,
        aligned["factor"].to_numpy(dtype=float),
        rcond=None,
    )
    residuals = aligned["factor"].to_numpy(dtype=float) - matrix @ coefficients
    return pd.Series(residuals, index=aligned.index, name=values.name)


__all__ = [
    "compute_cross_sectional_factor",
    "factor_input_names",
    "required_fundamental_fields",
]
