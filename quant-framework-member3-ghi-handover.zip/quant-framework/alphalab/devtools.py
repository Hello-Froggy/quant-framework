"""Local development diagnostics that never expose credential values."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
from pathlib import Path
from typing import Any

from alphalab.dataio.catalog import DataCatalog
from alphalab.utils.env import load_env_files
from alphalab.utils.paths import DATA_DIR, REPO_ROOT

_RQ_KEYS = ("RQ_USER", "RQ_PASSWORD", "RQ_HOST")


def serve_workbench(*, host: str = "127.0.0.1", port: int = 8000, agent: str = "local", agent_port: int = 0) -> None:
    """Serve the built browser workbench through the existing backend."""

    if not 1 <= port <= 65535:
        raise RuntimeError("Port must be between 1 and 65535.")
    index = Path(REPO_ROOT) / "build" / "web" / "index.html"
    if not index.is_file():
        raise RuntimeError(
            "Frontend build is missing. Run npm --prefix apps/desktop ci, "
            "then npm --prefix apps/desktop run build."
        )
    try:
        import uvicorn
    except ImportError as exc:
        raise RuntimeError('Install the backend first: python -m pip install -e ".[app,dev]"') from exc
    print(f"AlphaLab: http://{host}:{port}/app/", flush=True)
    os.environ["ALPHALAB_AGENT_MODE"] = agent
    if agent == "local":
        from alphalab.local_agent import serve_with_local_agent

        serve_with_local_agent(Path(REPO_ROOT), host=host, port=port, agent_port=agent_port)
    else:
        uvicorn.run("apps.api.main:app", host=host, port=port)


def doctor_report() -> dict[str, Any]:
    """Return bounded readiness checks for the one supported local runtime."""

    load_env_files()
    runtime = DataCatalog().summary()
    checks = {
        "python": _executable_check(sys.executable, ["--version"], minimum=(3, 10)),
        "node": _command_check("node", ["--version"]),
        "demo_data": _demo_data_check(),
        "rq": _rq_check(),
        "runtime": runtime,
        "runtime_execution": _runtime_execution_check(runtime),
        "frontend": _frontend_check(),
        "pyrefly": _command_check("pyrefly", ["--version"]),
        "ruff": _module_check("ruff"),
        "ports": {
            "8000": _port_status(8000),
            "5173": _port_status(5173),
        },
    }
    required = ("python", "node", "demo_data", "frontend", "runtime_execution")
    status = (
        "ready"
        if all(checks[name].get("status") == "ready" for name in required)
        else "degraded"
    )
    return {"status": status, "checks": checks}


def _runtime_execution_check(runtime: dict[str, Any]) -> dict[str, Any]:
    required = ("rq.instruments", "rq.bars", "rq.paused")
    states = {
        str(item.get("id")): str(item.get("status"))
        for item in runtime.get("datasets", [])
    }
    missing = [dataset for dataset in required if states.get(dataset) != "ready"]
    return {
        "status": "ready" if not missing else "missing",
        "required_datasets": list(required),
        "missing": missing,
    }


def _executable_check(
    executable: str,
    arguments: list[str],
    *,
    minimum: tuple[int, int] | None = None,
) -> dict[str, Any]:
    result = _run_version(executable, arguments)
    if minimum and sys.version_info < minimum:
        result["status"] = "unsupported"
    result["executable"] = executable
    return result


def _command_check(command: str, arguments: list[str]) -> dict[str, Any]:
    suffix = ".exe" if os.name == "nt" else ""
    adjacent = Path(sys.executable).with_name(f"{command}{suffix}")
    executable = str(adjacent) if adjacent.is_file() else shutil.which(command)
    if executable is None:
        return {"status": "missing", "version": None, "executable": None}
    result = _run_version(executable, arguments)
    result["executable"] = executable
    return result


def _module_check(module: str) -> dict[str, Any]:
    result = _run_version(sys.executable, ["-m", module, "--version"])
    result["executable"] = sys.executable
    return result


def _run_version(executable: str, arguments: list[str]) -> dict[str, Any]:
    try:
        value = subprocess.check_output(
            [executable, *arguments],
            text=True,
            stderr=subprocess.STDOUT,
            timeout=5,
        ).strip()
    except (OSError, subprocess.SubprocessError):
        return {"status": "invalid", "version": None}
    return {"status": "ready", "version": value or platform.python_version()}


def _rq_check() -> dict[str, Any]:
    present = {key: bool(os.getenv(key, "").strip()) for key in _RQ_KEYS}
    missing = [key for key, configured in present.items() if not configured]
    return {
        "status": "configured" if not missing else "not_configured",
        "configured": not missing,
        "missing": missing,
    }


def _demo_data_check() -> dict[str, Any]:
    manifest_path = DATA_DIR / "manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError) as exc:
        return {"status": "invalid", "error": str(exc), "files": 0}
    failures: list[str] = []
    files = manifest.get("files", {})
    for relative, metadata in files.items():
        path = Path(REPO_ROOT) / relative
        if not path.is_file():
            failures.append(f"missing:{relative}")
            continue
        # The manifest contains immutable samples, never the local app database.
        expected = metadata.get("sha256")
        if expected and _sha256(path) != expected:
            failures.append(f"checksum:{relative}")
    return {
        "status": "ready" if not failures else "invalid",
        "files": len(files),
        "symbol_count": manifest.get("symbol_count"),
        "cutoff_date": manifest.get("cutoff_date"),
        "issues": failures,
    }


def _frontend_check() -> dict[str, Any]:
    frontend = Path(REPO_ROOT) / "apps" / "desktop"
    source_ready = (frontend / "package.json").is_file() and (frontend / "src").is_dir()
    return {
        "status": "ready" if source_ready else "missing",
        "source": "ready" if source_ready else "missing",
        "dependencies": "ready" if (frontend / "node_modules").is_dir() else "missing",
        "build": "ready" if (Path(REPO_ROOT) / "build" / "web" / "index.html").is_file() else "missing",
    }


def _port_status(port: int) -> str:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as connection:
        connection.settimeout(0.2)
        return "listening" if connection.connect_ex(("127.0.0.1", port)) == 0 else "available"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


__all__ = ["doctor_report", "serve_workbench"]
