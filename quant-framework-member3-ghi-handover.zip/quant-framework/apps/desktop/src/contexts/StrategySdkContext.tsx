import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react"

import { api } from "@/lib/api"
import { useWorkspace } from "@/contexts/WorkspaceContext"

export interface SdkParameter {
  name: string
  annotation: string | null
  default: unknown
  editable: boolean
  custom_source: string | null
  label: string | null
  description: string | null
  minimum: number | null
  maximum: number | null
  step: number | null
}

export interface SdkEntrypoint {
  kind: "universe" | "factor" | "schedule" | "signal" | "portfolio" | "event" | "execution_data_fill" | "execution"
  id: string
  function: string
  label: string | null
  event: string | null
  metadata: Record<string, unknown>
  parameters: SdkParameter[]
  line: number
}

export interface SourceInspection {
  valid: boolean
  sdk_version: number
  source_sha256: string
  source_bytes: number
  validator_version: string
  entrypoints: SdkEntrypoint[]
  data_requirements: Record<string, unknown>
  runtime_requirements: Record<string, unknown>
  warnings: Array<{ line: number; code: string; message: string }>
}

export interface SourcePackage {
  project_id: string
  revision: number
  parent_revision: number | null
  source_sha256: string
  sdk_version: number
  validator_version: string
  manifest: Array<Record<string, unknown>>
  parameters: Record<string, Record<string, unknown>>
  created_at: string
  source?: string
}

export interface StrategyProject {
  id: string
  strategy_id: string
  strategy_path: string
  strategies: Array<{ id: string; name: string; path: string; current_revision: number }>
  name: string
  description: string
  profile: "runtime"
  current_revision: number
  draft_parent_revision: number | null
  draft_source_sha256: string
  draft_source: string
  strategy_source_sha256: string
  strategy_source: string
  source_units: Array<{
    path: string
    kind: "strategy" | "factor"
    source_sha256: string
    position: number
  }>
  dirty: boolean
  settings: Record<string, unknown>
  built_in: boolean
  editable: boolean
  current_package: SourcePackage
  inspection: SourceInspection
  created_at: string
  updated_at: string
}

type ProjectSummary = Omit<StrategyProject, "draft_source" | "strategy_source" | "inspection">

interface StrategySdkValue {
  projects: ProjectSummary[]
  project: StrategyProject | null
  loading: boolean
  error: string
  refresh: (preferredId?: string) => Promise<void>
  openProject: (projectId: string, strategyId?: string) => Promise<StrategyProject>
  strategyUrl: (suffix?: string) => string
  createStrategy: (id: string, name: string, copyFrom: string) => Promise<StrategyProject>
  renameStrategy: (name: string) => Promise<StrategyProject>
  createProject: (targetId: string, name: string) => Promise<StrategyProject>
  updateDraft: (source: string) => Promise<StrategyProject>
  updateMetadata: (values: Pick<StrategyProject, "name" | "description" | "profile" | "settings">) => Promise<StrategyProject>
  structuredEdit: (payload: Record<string, unknown>) => Promise<StrategyProject>
  addFactorSource: (source: string) => Promise<{ project: StrategyProject; factor: SdkEntrypoint }>
  installFactorTemplate: (templateId: string) => Promise<{ project: StrategyProject; factor: SdkEntrypoint }>
  removeProject: () => Promise<void>
}

const StrategySdkContext = createContext<StrategySdkValue | null>(null)

export function strategyApiPath(projectId: string, strategyId = "main", suffix = "") {
  return `/strategy/projects/${encodeURIComponent(projectId)}${suffix}${strategyId === "main" ? "" : `?strategy_id=${encodeURIComponent(strategyId)}`}`
}

export function StrategySdkProvider({ children }: { children: ReactNode }) {
  const strategySelection = useRef<Record<string, string>>({})
  const {
    selectedStrategy,
    setSelectedStrategy,
    setSelectedStrategyEditable,
    setSelectedStrategyRevision,
  } = useWorkspace()
  const [projects, setProjects] = useState<ProjectSummary[]>([])
  const [project, setProject] = useState<StrategyProject | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  const adopt = useCallback((value: StrategyProject) => {
    strategySelection.current[value.id] = value.strategy_id
    setProject(value)
    const summary = Object.fromEntries(
      Object.entries(value).filter(([key]) => !["draft_source", "strategy_source", "inspection"].includes(key)),
    ) as ProjectSummary
    setProjects((current) => current.some((item) => item.id === value.id)
      ? current.map((item) => item.id === value.id ? summary : item)
      : [...current, summary])
    setSelectedStrategy(value.id)
    setSelectedStrategyEditable(value.editable)
    setSelectedStrategyRevision(value.current_revision)
    window.dispatchEvent(new CustomEvent("alphalab:strategyUpdated", { detail: value }))
    return value
  }, [setSelectedStrategy, setSelectedStrategyEditable, setSelectedStrategyRevision])

  const openProject = useCallback(async (projectId: string, strategyId?: string) => {
    setLoading(true)
    setError("")
    try {
      return adopt(await api.get<StrategyProject>(strategyApiPath(projectId, strategyId ?? strategySelection.current[projectId])))
    } catch (reason) {
      // Failed navigation must not replace the still-valid current workbench.
      if (!project) setError(reason instanceof Error ? reason.message : String(reason))
      throw reason
    } finally {
      setLoading(false)
    }
  }, [adopt, project])

  const refresh = useCallback(async (preferredId?: string) => {
    setLoading(true)
    setError("")
    try {
      const rows = await api.get<ProjectSummary[]>("/strategy/projects")
      setProjects(rows)
      const next = rows.find((item) => item.id === (preferredId ?? selectedStrategy))
        ?? rows.find((item) => item.id === "sdk-v1-default")
        ?? rows[0]
      if (next) adopt(await api.get<StrategyProject>(strategyApiPath(next.id, strategySelection.current[next.id])))
      else setProject(null)
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
    } finally {
      setLoading(false)
    }
  }, [adopt, selectedStrategy])

  useEffect(() => { void refresh() }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const commitSavedProject = useCallback(async (value: StrategyProject) => {
    if (!value.dirty) return adopt(value)
    try {
      await api.post<SourcePackage>(strategyApiPath(value.id, value.strategy_id, "/revisions"), {
        expected_source_sha256: value.draft_source_sha256,
        confirm_save: true,
        confirm_python_execution: true,
      })
      return adopt(await api.get<StrategyProject>(strategyApiPath(value.id, value.strategy_id)))
    } catch (reason) {
      adopt(value)
      throw reason
    }
  }, [adopt])

  const value = useMemo<StrategySdkValue>(() => ({
    projects,
    project,
    loading,
    error,
    refresh,
    openProject,
    strategyUrl: (suffix = "") => strategyApiPath(project?.id ?? "", project?.strategy_id, suffix),
    createStrategy: async (id, name, copyFrom) => {
      if (!project) throw new Error("请先选择项目")
      return adopt(await api.post<StrategyProject>(`/strategy/projects/${project.id}/strategies`, {
        strategy_id: id, name, copy_from: copyFrom, confirm_write: true,
      }))
    },
    renameStrategy: async (name) => {
      if (!project) throw new Error("请先选择策略")
      return adopt(await api.put<StrategyProject>(`/strategy/projects/${project.id}/strategies/${project.strategy_id}/name`, {
        name, confirm_write: true,
      }))
    },
    createProject: async (targetId, name) => {
      const created = await api.post<StrategyProject>("/strategy/projects", {
        project_id: targetId,
        name,
        confirm_save: true,
        confirm_python_execution: true,
      })
      await refresh(created.id)
      return created
    },
    updateDraft: async (source) => {
      if (!project) throw new Error("请先选择项目")
      return commitSavedProject(await api.put<StrategyProject>(strategyApiPath(project.id, project.strategy_id, "/draft"), {
        source,
        expected_source_sha256: project.draft_source_sha256,
        confirm_write: true,
        confirm_python_execution: true,
      }))
    },
    updateMetadata: async (values) => adopt(await api.put<StrategyProject>(
      strategyApiPath(project?.id ?? "", project?.strategy_id, "/metadata"),
      { ...values, confirm_write: true },
    )),
    structuredEdit: async (payload) => {
      if (!project) throw new Error("请先选择项目")
      const response = await api.post<{ project: StrategyProject }>(
        strategyApiPath(project.id, project.strategy_id, "/edits"),
        {
          ...payload,
          expected_source_sha256: project.draft_source_sha256,
          confirm_write: true,
          confirm_python_execution: true,
        },
      )
      return commitSavedProject(response.project)
    },
    addFactorSource: async (source) => {
      if (!project) throw new Error("请先选择项目")
      const response = await api.post<{ project: StrategyProject; factor: SdkEntrypoint }>(
        strategyApiPath(project.id, project.strategy_id, "/factors"),
        {
          source,
          expected_source_sha256: project.draft_source_sha256,
          confirm_write: true,
          confirm_python_execution: true,
        },
      )
      return { project: await commitSavedProject(response.project), factor: response.factor }
    },
    installFactorTemplate: async (templateId) => {
      if (!project) throw new Error("请先选择项目")
      const response = await api.post<{ project: StrategyProject; factor: SdkEntrypoint }>(
        strategyApiPath(project.id, project.strategy_id, `/factor-templates/${encodeURIComponent(templateId)}`),
        {
          expected_source_sha256: project.draft_source_sha256,
          confirm_write: true,
          confirm_python_execution: true,
        },
      )
      return { project: await commitSavedProject(response.project), factor: response.factor }
    },
    removeProject: async () => {
      if (!project) return
      await api.delete(`/strategy/projects/${project.id}?confirm_delete=true`)
      setSelectedStrategy(null)
      await refresh("sdk-v1-default")
    },
  }), [adopt, commitSavedProject, error, loading, openProject, project, projects, refresh, setSelectedStrategy])

  return <StrategySdkContext.Provider value={value}>{children}</StrategySdkContext.Provider>
}

export function useStrategySdk(): StrategySdkValue {
  const value = useContext(StrategySdkContext)
  if (!value) throw new Error("useStrategySdk must be used within StrategySdkProvider")
  return value
}
