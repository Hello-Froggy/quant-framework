"""Runtime dataset catalog and local coverage inspection."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path
from threading import RLock
from typing import Literal

import pandas as pd
import pyarrow.compute as pc
import pyarrow.parquet as pq

from alphalab.utils.paths import RUNTIME_DIR

DatasetState = Literal["ready", "missing", "invalid", "not_configured"]


@dataclass(frozen=True)
class DatasetSpec:
    id: str
    label: str
    relative_path: str
    key_columns: tuple[str, ...]
    date_column: str | None
    source: str
    provider_api: tuple[str, ...]
    research_role: str
    field_policy: str
    configured: bool = True


DATASET_SPECS: tuple[DatasetSpec, ...] = (
    DatasetSpec(
        "rq.instruments",
        "RQ instruments",
        "rq/instruments",
        ("snapshot_date", "symbol"),
        "snapshot_date",
        "rq",
        ("all_instruments",),
        "research_scope",
        "provider_snapshot_schema",
    ),
    DatasetSpec(
        "rq.bars",
        "RQ adjusted and unadjusted daily bars",
        "rq/bars",
        ("date", "symbol"),
        "date",
        "rq",
        ("get_price",),
        "factor_input",
        "provider_daily_schema_plus_raw_ohlc",
    ),
    DatasetSpec(
        "rq.paused",
        "RQ historical suspension state",
        "rq/market_state/paused",
        ("date", "symbol"),
        "date",
        "rq",
        ("is_suspended", "get_price"),
        "execution_input",
        "boolean_daily_state",
    ),
    DatasetSpec(
        "rq.is_st",
        "RQ historical ST state",
        "rq/market_state/is_st",
        ("date", "symbol"),
        "date",
        "rq",
        ("is_st_stock",),
        "strategy_input",
        "boolean_daily_state",
    ),
    DatasetSpec(
        "rq.daily_factors",
        "RQ daily point-in-time factors",
        "rq/market_state/daily_factors",
        ("date", "symbol", "field"),
        "date",
        "rq",
        ("get_factor",),
        "point_in_time_factor_input",
        "long_daily_field_value",
    ),
    DatasetSpec(
        "rq.index_components",
        "RQ historical index components",
        "rq/market_state/index_components",
        ("date", "index_symbol", "symbol"),
        "date",
        "rq",
        ("index_components",),
        "point_in_time_universe_input",
        "dated_membership_snapshot",
    ),
    DatasetSpec(
        "rq.financials.income",
        "RQ PIT income statements",
        "rq/financials/statement=income",
        ("symbol", "quarter", "info_date", "if_adjusted"),
        "info_date",
        "rq",
        ("get_pit_financials_ex",),
        "point_in_time_staging",
        "configured_statement_fields",
    ),
    DatasetSpec(
        "rq.financials.balance",
        "RQ PIT balance sheets",
        "rq/financials/statement=balance",
        ("symbol", "quarter", "info_date", "if_adjusted"),
        "info_date",
        "rq",
        ("get_pit_financials_ex",),
        "point_in_time_staging",
        "configured_statement_fields",
    ),
    DatasetSpec(
        "canonical.fundamentals",
        "Canonical point-in-time fundamentals",
        "canonical/fundamentals",
        ("symbol", "quarter"),
        "available_date",
        "derived",
        ("get_pit_financials_ex", "get_price"),
        "factor_input",
        "schema_discovered_canonical_fields",
    ),
    DatasetSpec(
        "runtime.factor_returns",
        "Runtime factor returns",
        "canonical/factor_returns",
        ("date",),
        "date",
        "derived",
        ("get_yield_curve", "get_price", "get_pit_financials_ex"),
        "attribution_input",
        "derived_factor_return_schema",
    ),
)
DATASETS = {spec.id: spec for spec in DATASET_SPECS}


@dataclass(frozen=True)
class _FileCoverage:
    rows: int
    start: pd.Timestamp | None
    end: pd.Timestamp | None
    symbols: frozenset[str]
    dated_symbols: frozenset[str]


_COVERAGE_LOCK = RLock()


@lru_cache(maxsize=512)
def _file_coverage(
    path: Path, size: int, modified_ns: int, changed_ns: int, date_column: str | None,
) -> _FileCoverage:
    """Cache small coverage summaries, never full research data frames.

    File identity changes invalidate entries after publication, including atomic
    replacement. Callers serialize cache misses so simultaneous workbench reads
    do not decode the same partition more than once.
    """
    with pq.ParquetFile(path) as parquet:
        names = parquet.schema_arrow.names
        columns = [name for name in (date_column, "symbol") if name and name in names]
        table = parquet.read(columns=columns)
        start = end = None
        if date_column and date_column in names:
            dates = pd.to_datetime(table[date_column].unique().to_pandas(), errors="coerce").dropna()
            if not dates.empty:
                start, end = pd.Timestamp(dates.min()), pd.Timestamp(dates.max())
        symbols = frozenset(
            str(value).upper() for value in table["symbol"].unique().to_pylist()
            if value is not None
        ) if "symbol" in names else frozenset()
        dated_symbols = symbols
        if date_column and date_column in names and "symbol" in names:
            # Market symbol discovery excludes rows with an unusable date, just
            # like the provider's normalized bars view.
            date_values = table[date_column].unique()
            parsed = pd.to_datetime(date_values.to_pandas(), errors="coerce")
            if parsed.isna().any():
                valid_values = date_values.filter(parsed.notna().to_numpy())
                valid_rows = table.filter(pc.is_in(table[date_column], value_set=valid_values))
                dated_symbols = frozenset(
                    str(value).upper() for value in valid_rows["symbol"].unique().to_pylist()
                    if value is not None
                )
        return _FileCoverage(parquet.metadata.num_rows, start, end, symbols, dated_symbols)


def _coverage(path: Path, date_column: str | None) -> _FileCoverage:
    resolved = path.resolve()
    stat = resolved.stat()
    with _COVERAGE_LOCK:
        return _file_coverage(resolved, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, date_column)


class DataCatalog:
    def __init__(self, root: str | Path | None = None):
        self.root = Path(root) if root is not None else RUNTIME_DIR

    def spec(self, dataset: str) -> DatasetSpec:
        try:
            return DATASETS[dataset]
        except KeyError as exc:
            raise KeyError(f"Unknown runtime dataset: {dataset}") from exc

    def path(self, dataset: str) -> Path:
        return self.root / self.spec(dataset).relative_path

    @staticmethod
    def clear_cache() -> None:
        """Discard shared coverage metadata for an explicit refresh."""
        with _COVERAGE_LOCK:
            _file_coverage.cache_clear()

    def files(
        self, dataset: str, *, start: str | None = None, end: str | None = None,
    ) -> list[Path]:
        files = sorted(self.path(dataset).rglob("*.parquet"))
        if start is None and end is None:
            return files
        lower = pd.Timestamp(start) if start is not None else None
        upper = pd.Timestamp(end) if end is not None else None
        selected = []
        date_column = self.spec(dataset).date_column
        for path in files:
            info = _coverage(path, date_column)
            if lower is not None and info.end is not None and info.end < lower:
                continue
            if upper is not None and info.start is not None and info.start > upper:
                continue
            selected.append(path)
        return selected

    def symbols(self, dataset: str, *, dated_only: bool = False) -> list[str]:
        spec = self.spec(dataset)
        symbols: set[str] = set()
        for path in self.files(dataset):
            coverage = _coverage(path, spec.date_column)
            symbols.update(coverage.dated_symbols if dated_only else coverage.symbols)
        return sorted(symbols)

    def status(self, dataset: str) -> dict:
        spec = self.spec(dataset)
        base = {
            **asdict(spec),
            "path": str(self.path(dataset)),
            "files": 0,
            "rows": 0,
            "bytes": 0,
            "date_start": None,
            "date_end": None,
            "symbol_count": 0,
            "error": None,
        }
        if not spec.configured:
            return {**base, "status": "not_configured"}
        files = self.files(dataset)
        if not files:
            return {**base, "status": "missing"}
        try:
            rows = 0
            date_start: pd.Timestamp | None = None
            date_end: pd.Timestamp | None = None
            symbols: set[str] = set()
            for path in files:
                coverage = _coverage(path, spec.date_column)
                rows += coverage.rows
                if coverage.start is not None:
                    date_start = coverage.start if date_start is None else min(date_start, coverage.start)
                if coverage.end is not None:
                    date_end = coverage.end if date_end is None else max(date_end, coverage.end)
                symbols.update(coverage.symbols)
            return {
                **base,
                "status": "ready",
                "files": len(files),
                "rows": rows,
                "bytes": sum(path.stat().st_size for path in files),
                "date_start": (date_start.strftime("%Y-%m-%d") if date_start is not None else None),
                "date_end": (date_end.strftime("%Y-%m-%d") if date_end is not None else None),
                "symbol_count": len(symbols),
            }
        except Exception as exc:
            return {**base, "status": "invalid", "files": len(files), "error": str(exc)}

    def list(self) -> list[dict]:
        return [self.status(spec.id) for spec in DATASET_SPECS]

    def summary(self) -> dict:
        datasets = self.list()
        ready = sum(item["status"] == "ready" for item in datasets)
        configured = sum(item["configured"] for item in datasets)
        state = "ready" if ready == configured else ("partial" if ready else "missing")
        return {
            "root": str(self.root),
            "status": state,
            "ready": ready,
            "total": len(datasets),
            "configured": configured,
            "datasets": datasets,
        }


__all__ = ["DATASETS", "DATASET_SPECS", "DataCatalog", "DatasetSpec", "DatasetState"]
