"""Profile-aware data queries used by the workstation API."""

from __future__ import annotations

import json
import re

import pandas as pd

from alphalab import ResultStore, create_default_engine, create_runtime_engine
from alphalab.dataio import DataEngine, MissingDataError
from alphalab.dataio.catalog import DataCatalog
from alphalab.dataio.schema import DatasetField, discover_parquet_fields
from alphalab.dataio.symbols import canonical_a_share_symbol
from alphalab.utils.paths import DATA_DIR, FUNDAMENTAL_DIR, MARKET_DIR

_DATASET_METADATA_FIELDS = {
    "market_bars": {"date", "symbol"},
    "fundamentals": {"quarter", "available_date", "symbol"},
}


def load_manifest() -> dict:
    path = DATA_DIR / "manifest.json"
    if not path.exists():
        raise MissingDataError(f"Bundled data manifest is missing: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def list_provider_status() -> dict:
    engine = create_runtime_engine()
    runtime = DataCatalog().summary()
    runtime_factor_status = next(
        (item["status"] for item in runtime["datasets"] if item["id"] == "runtime.factor_returns"),
        "missing",
    )
    return {
        "providers": engine.providers(),
        "active_profile": "runtime",
        "profiles": {
            "runtime": {
                "status": runtime["status"],
                "latest_date": next(
                    (item["date_end"] for item in runtime["datasets"] if item["id"] == "rq.bars"),
                    None,
                ),
                "symbol_count": next(
                    (
                        item["symbol_count"]
                        for item in runtime["datasets"]
                        if item["id"] == "rq.instruments" and item["status"] == "ready"
                    ),
                    next(
                        (
                            item["symbol_count"]
                            for item in runtime["datasets"]
                            if item["id"] == "rq.bars"
                        ),
                        0,
                    ),
                ),
                "factor_returns": runtime_factor_status,
            },
        },
        "latest_date": next(
            (item["date_end"] for item in runtime["datasets"] if item["id"] == "rq.bars"),
            None,
        ),
        "sample_start": next(
            (item["date_start"] for item in runtime["datasets"] if item["id"] == "rq.bars"),
            None,
        ),
        "symbol_count": next(
            (item["symbol_count"] for item in runtime["datasets"] if item["id"] == "rq.bars"),
            0,
        ),
        "realtime": {"status": "not_configured", "source": None},
        "datasets": {
            item["id"]: {
                key: item.get(key)
                for key in ("status", "rows", "date_start", "date_end", "symbol_count")
            }
            for item in runtime["datasets"]
        },
        "runtime": {key: runtime.get(key) for key in ("status", "ready", "total", "configured")}
        | {
            "datasets": [
                {
                    key: item.get(key)
                    for key in (
                        "id",
                        "label",
                        "status",
                        "configured",
                        "rows",
                        "date_start",
                        "date_end",
                        "symbol_count",
                    )
                }
                for item in runtime["datasets"]
            ]
        },
    }


def _engine(profile: str) -> DataEngine:
    if profile == "demo":
        return create_default_engine()
    if profile == "runtime":
        return create_runtime_engine()
    raise ValueError("profile must be demo or runtime")


def research_dataset_schema(profile: str, dataset: str) -> tuple[DatasetField, ...]:
    """Discover the actual columns exposed by one research-data endpoint."""

    if profile not in {"demo", "runtime"}:
        raise ValueError("profile must be demo or runtime")
    if dataset not in _DATASET_METADATA_FIELDS:
        raise KeyError(f"unknown research dataset: {dataset}")
    if profile == "demo":
        paths = {
            "market_bars": [MARKET_DIR / "bars.parquet"],
            "fundamentals": [FUNDAMENTAL_DIR / "fundamentals.parquet"],
        }[dataset]
    else:
        catalog = DataCatalog()
        runtime_dataset = {
            "market_bars": "rq.bars",
            "fundamentals": "canonical.fundamentals",
        }[dataset]
        paths = catalog.files(runtime_dataset)
    return discover_parquet_fields(paths)


def research_value_fields(profile: str, dataset: str) -> tuple[str, ...]:
    """Return every non-key field in the current physical dataset schema."""

    metadata = _DATASET_METADATA_FIELDS.get(dataset)
    if metadata is None:
        raise KeyError(f"unknown research dataset: {dataset}")
    return tuple(
        field.name
        for field in research_dataset_schema(profile, dataset)
        if field.name not in metadata
    )


def _profile_range(profile: str) -> tuple[str, str]:
    if profile == "demo":
        manifest = load_manifest()
        return manifest["sample_start"], manifest["cutoff_date"]
    status = DataCatalog().status("rq.bars")
    if status["status"] != "ready" or not status["date_start"] or not status["date_end"]:
        raise MissingDataError("RQData 日线行情尚未就绪，请先完成数据同步。")
    return status["date_start"], status["date_end"]


def market_symbol_options(profile: str = "demo") -> list[dict[str, str | None]]:
    engine = _engine(profile)
    symbols = engine.get_symbols()
    if profile == "runtime" and not symbols:
        raise MissingDataError("RQData 日线行情尚未就绪，请先完成数据同步。")
    names: dict[str, str] = {}
    if profile == "demo":
        names.update(
            {
                str(symbol).strip().upper(): str(name).strip()
                for symbol, name in load_manifest().get("symbol_names", {}).items()
                if str(symbol).strip() and str(name).strip()
            }
        )
    instruments = engine.get_instruments(engine.get_latest_date())
    if not instruments.empty and "symbol" in instruments:
        name_column = next(
            (column for column in ("name", "display_name") if column in instruments), None
        )
        if name_column:
            for symbol, name in instruments[["symbol", name_column]].itertuples(index=False):
                normalized_symbol = str(symbol).strip().upper()
                normalized_name = "" if pd.isna(name) else str(name).strip()
                if normalized_symbol and normalized_name:
                    names[normalized_symbol] = normalized_name
    return [{"symbol": symbol, "name": names.get(symbol)} for symbol in symbols]


def market_bars(
    symbol: str,
    start: str | None = None,
    end: str | None = None,
    profile: str = "demo",
) -> list[dict]:
    normalized = normalize_market_symbol(symbol, profile)
    engine = _engine(profile)
    if normalized not in engine.get_symbols():
        raise KeyError(normalized)
    profile_start, profile_end = _profile_range(profile)
    start = start or profile_start
    end = end or profile_end
    if pd.Timestamp(start) > pd.Timestamp(end):
        raise ValueError("start must be on or before end")
    frame = engine.get_bars([normalized], start, end, strict=True, use_cache=False)
    frame["date"] = pd.to_datetime(frame["date"]).dt.strftime("%Y-%m-%d")
    return frame.to_dict("records")


def normalize_market_symbol(symbol: str, profile: str = "runtime") -> str:
    """Accept framework and RQData codes at the dashboard input boundary."""
    value = symbol.strip().upper()
    if profile == "demo":
        return value
    if not re.fullmatch(r"[0-9]{6}(?:\.(?:SH|SZ|BJ|XSHG|XSHE|XBEI))?", value):
        raise ValueError(
            "证券代码格式不支持，请输入 000001.SZ 或 RQData 格式 000001.XSHE。"
        )
    return canonical_a_share_symbol(value)


def fundamentals(
    symbols: list[str],
    fields: list[str] | None = None,
    start_quarter: str | None = None,
    end_quarter: str | None = None,
    asof_date: str | None = None,
    profile: str = "demo",
    limit: int = 100,
) -> dict:
    normalized_symbols = list(
        dict.fromkeys(normalize_market_symbol(symbol, profile) for symbol in symbols)
    )
    if not normalized_symbols:
        raise ValueError("at least one symbol is required")
    engine = _engine(profile)
    unknown_symbols = sorted(set(normalized_symbols) - set(engine.get_symbols()))
    if unknown_symbols:
        raise KeyError(f"Unknown symbols: {unknown_symbols}")
    available_fields = research_value_fields(profile, "fundamentals")
    if not available_fields:
        raise MissingDataError(f"No fundamental schema is available for profile {profile!r}")
    requested_fields = list(dict.fromkeys(fields or available_fields))
    unknown_fields = sorted(set(requested_fields) - set(available_fields))
    if unknown_fields:
        raise KeyError(f"Unknown fundamental fields: {unknown_fields}")
    profile_start, profile_end = _profile_range(profile)
    start_quarter = (start_quarter or _quarter_label(profile_start)).lower()
    end_quarter = (end_quarter or _quarter_label(profile_end)).lower()
    if start_quarter > end_quarter:
        raise ValueError("start_quarter must be on or before end_quarter")
    effective_asof = asof_date or profile_end
    frame = engine.get_fundamentals(
        normalized_symbols,
        requested_fields,
        start_quarter,
        end_quarter,
        asof_date=effective_asof,
        strict=True,
        use_cache=False,
    )
    preview = frame.head(limit).copy()
    if "available_date" in preview:
        preview["available_date"] = pd.to_datetime(
            preview["available_date"], errors="coerce"
        ).dt.strftime("%Y-%m-%d")
    return {
        "profile": profile,
        "symbols": normalized_symbols,
        "fields": requested_fields,
        "start_quarter": start_quarter,
        "end_quarter": end_quarter,
        "asof_date": effective_asof,
        "matched_rows": len(frame),
        "returned_rows": len(preview),
        "truncated": len(frame) > len(preview),
        "rows": preview.where(pd.notna(preview), None).to_dict("records"),
    }


def factor_returns(
    names: list[str] | None = None,
    start: str | None = None,
    end: str | None = None,
    profile: str = "demo",
) -> dict:
    if profile not in {"demo", "runtime"}:
        raise ValueError("profile must be demo or runtime")
    available = {"MKT", "SMB", "HML", "MOM", "RMW", "rf"}
    requested = names or ["MKT", "SMB", "HML", "MOM", "RMW", "rf"]
    unknown = sorted(set(requested) - available)
    if unknown:
        raise KeyError(", ".join(unknown))
    if profile == "runtime" and DataCatalog().status("runtime.factor_returns")["status"] != "ready":
        raise MissingDataError("RQData 因子收益尚未就绪，请先同步完整研究数据。")
    profile_start, profile_end = _profile_range(profile)
    frame = _engine(profile).get_factors(
        requested,
        start or profile_start,
        end or profile_end,
        strict=True,
        use_cache=False,
    )
    values = frame.reset_index().rename(columns={frame.index.name or "index": "date"})
    values["date"] = pd.to_datetime(values["date"]).dt.strftime("%Y-%m-%d")
    return {"names": requested, "rows": values.to_dict("records")}


def _quarter_label(value: str) -> str:
    timestamp = pd.Timestamp(value)
    return f"{timestamp.year}q{timestamp.quarter}"


def store_stats() -> dict:
    store = ResultStore()
    try:
        return store.stats()
    finally:
        store.close()


__all__ = [
    "_engine",
    "_profile_range",
    "factor_returns",
    "fundamentals",
    "list_provider_status",
    "load_manifest",
    "market_bars",
    "market_symbol_options",
    "research_dataset_schema",
    "research_value_fields",
    "store_stats",
]
